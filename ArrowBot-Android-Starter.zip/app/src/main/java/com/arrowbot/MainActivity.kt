package com.arrowbot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
        }

        val title = TextView(this).apply {
            text = "ArrowBot"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Arrow Sort Master assistant"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        root.addView(subtitle, matchWrap())

        status = TextView(this).apply {
            text = "Status: Ready. Puzzle detection and solving are not implemented yet."
            textSize = 15f
            setPadding(0, 8, 0, 20)
        }
        root.addView(status, matchWrap())

        root.addView(button("Enable accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            status.text = "Status: Enable ArrowBot in Accessibility settings, then return here."
        }, matchWrap())

        root.addView(button("Capture board (coming next)") {
            status.text = "Status: Screen-capture flow is the next development step."
        }, matchWrap())

        root.addView(button("Find safe arrows (coming next)") {
            status.text = "Status: The arrow detector and puzzle solver are not implemented yet."
        }, matchWrap())

        root.addView(button("Start auto-play (disabled for now)") {
            status.text = "Status: Auto-play stays disabled until detection and solver tests pass."
        }, matchWrap())

        root.addView(button("Stop / reset") {
            status.text = "Status: Stopped. No automated taps are currently running."
        }, matchWrap())

        val note = TextView(this).apply {
            text = "\nSafety note: Android will show permission prompts for screen capture. Only enable accessibility for an app you trust. This starter does not yet capture the screen or tap the game."
            textSize = 13f
        }
        root.addView(note, matchWrap())

        setContentView(ScrollView(this).apply {
            addView(root, ViewGroup.LayoutParams(-1, -2))
        })
    }

    private fun button(label: String, action: () -> Unit) =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 10 }
}
