package com.arrowbot

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Starter only. Gesture dispatch will be added after board detection and
 * the puzzle solver are validated. No taps are issued by this version.
 */
class ArrowAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit
}
